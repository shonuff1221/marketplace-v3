exports.id = 413;
exports.ids = [413];
exports.modules = {

/***/ 5491:
/***/ ((module) => {

// Exports
module.exports = {
	"navContainer": "Navbar_navContainer__xv_QU",
	"nav": "Navbar_nav__yOCRc",
	"navLeft": "Navbar_navLeft__Vf45q",
	"navMiddle": "Navbar_navMiddle__CR3pY",
	"link": "Navbar_link__Qi5VS",
	"homeLink": "Navbar_homeLink__LVFUJ",
	"navRight": "Navbar_navRight__AgYnC",
	"profileImage": "Navbar_profileImage__Ap0dv",
	"buttonLink": "Navbar_buttonLink__rmaPb",
	"navConnect": "Navbar_navConnect__rTccf"
};


/***/ }),

/***/ 1242:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IB: () => (/* binding */ NETWORK),
/* harmony export */   YJ: () => (/* binding */ MARKETPLACE_ADDRESS),
/* harmony export */   f2: () => (/* binding */ NFT_COLLECTION_ADDRESS),
/* harmony export */   t0: () => (/* binding */ ETHERSCAN_URL)
/* harmony export */ });
/* harmony import */ var _thirdweb_dev_chains__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5488);
/* harmony import */ var _thirdweb_dev_chains__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_thirdweb_dev_chains__WEBPACK_IMPORTED_MODULE_0__);
/** Replace the values below with the addresses of your smart contracts. */ // 1. Set up the network your smart contracts are deployed to.
// First, import the chain from the package, then set the NETWORK variable to the chain.

const NETWORK = _thirdweb_dev_chains__WEBPACK_IMPORTED_MODULE_0__.Goerli;
// 2. The address of the marketplace V3 smart contract.
// Deploy your own: https://thirdweb.com/thirdweb.eth/MarketplaceV3
const MARKETPLACE_ADDRESS = "0xCCf4FfB0429b56028E545cd64c9b201d6757ddfe";
// 3. The address of your NFT collection smart contract.
const NFT_COLLECTION_ADDRESS = "0x7620Ec69fAe4dB8bc23989810453707E1Db157a9";
// (Optional) Set up the URL of where users can view transactions on
// For example, below, we use Mumbai.polygonscan to view transactions on the Mumbai testnet.
const ETHERSCAN_URL = "https://goerli.etherscan.io/";


/***/ }),

/***/ 413:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: ./node_modules/.pnpm/react@18.2.0/node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(1527);
// EXTERNAL MODULE: external "@thirdweb-dev/react"
var react_ = __webpack_require__(2352);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.9_biqbaboplfbrettd7655fr4n2y/node_modules/next/image.js
var next_image = __webpack_require__(8797);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/.pnpm/next@13.4.9_biqbaboplfbrettd7655fr4n2y/node_modules/next/link.js
var next_link = __webpack_require__(1418);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/Navbar/Navbar.module.css
var Navbar_module = __webpack_require__(5491);
var Navbar_module_default = /*#__PURE__*/__webpack_require__.n(Navbar_module);
;// CONCATENATED MODULE: ./components/Navbar/Navbar.tsx





/**
 * Navigation bar that shows up on all pages.
 * Rendered in _app.tsx file above the page content.
 */ function Navbar() {
    const address = (0,react_.useAddress)();
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: (Navbar_module_default()).navContainer,
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("nav", {
            className: (Navbar_module_default()).nav,
            children: [
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: (Navbar_module_default()).navLeft,
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "/",
                            className: `${(Navbar_module_default()).homeLink} ${(Navbar_module_default()).navLeft}`,
                            children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: "/logo.png",
                                width: 48,
                                height: 48,
                                alt: "NFT marketplace sample logo"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: (Navbar_module_default()).navMiddle,
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/buy",
                                    className: (Navbar_module_default()).link,
                                    children: "Buy"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                    href: "/sell",
                                    className: (Navbar_module_default()).link,
                                    children: "Sell"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: (Navbar_module_default()).navRight,
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: (Navbar_module_default()).navConnect,
                            children: /*#__PURE__*/ jsx_runtime.jsx(react_.ConnectWallet, {
                                theme: "dark",
                                btnTitle: "Connect Wallet"
                            })
                        }),
                        address && /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            className: (Navbar_module_default()).link,
                            href: `/profile/${address}`,
                            children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                className: (Navbar_module_default()).profileImage,
                                src: "/user-icon.png",
                                width: 42,
                                height: 42,
                                alt: "Profile"
                            })
                        })
                    ]
                })
            ]
        })
    });
}

// EXTERNAL MODULE: external "nextjs-progressbar"
var external_nextjs_progressbar_ = __webpack_require__(8890);
var external_nextjs_progressbar_default = /*#__PURE__*/__webpack_require__.n(external_nextjs_progressbar_);
// EXTERNAL MODULE: ./const/contractAddresses.ts
var contractAddresses = __webpack_require__(1242);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(244);
;// CONCATENATED MODULE: ./pages/_app.tsx






function MyApp({ Component, pageProps }) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(react_.ThirdwebProvider, {
        activeChain: contractAddresses/* NETWORK */.IB,
        children: [
            /*#__PURE__*/ jsx_runtime.jsx((external_nextjs_progressbar_default()), {
                color: "var(--color-tertiary)",
                startPosition: 0.3,
                stopDelayMs: 200,
                height: 3,
                showOnShallow: true
            }),
            /*#__PURE__*/ jsx_runtime.jsx(Navbar, {}),
            /*#__PURE__*/ jsx_runtime.jsx(Component, {
                ...pageProps
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 244:
/***/ (() => {



/***/ })

};
;