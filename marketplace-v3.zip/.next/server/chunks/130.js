exports.id = 130;
exports.ids = [130];
exports.modules = {

/***/ 2814:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Token_container__CNJxv",
	"metadataContainer": "Token_metadataContainer__NXo6z",
	"listingContainer": "Token_listingContainer__KEv8I",
	"image": "Token_image__THR7w",
	"input": "Token_input__mtVaC",
	"contractMetadataContainer": "Token_contractMetadataContainer__W04ui",
	"imageContainer": "Token_imageContainer__UKE4B",
	"crossButton": "Token_crossButton__T99yY",
	"collectionImage": "Token_collectionImage__Lpjxv",
	"collectionName": "Token_collectionName__FH4Mn",
	"title": "Token_title__eeB_J",
	"nftOwnerContainer": "Token_nftOwnerContainer__15rAB",
	"nftOwnerImage": "Token_nftOwnerImage__5IWAs",
	"nftOwnerInfo": "Token_nftOwnerInfo__jLeIk",
	"label": "Token_label__Tb918",
	"nftOwnerAddress": "Token_nftOwnerAddress__P0d3_",
	"descriptionContainer": "Token_descriptionContainer__ScydP",
	"descriptionTitle": "Token_descriptionTitle__dbr58",
	"traitsContainer": "Token_traitsContainer__BrwT9",
	"traitContainer": "Token_traitContainer__U27l_",
	"eventsContainer": "Token_eventsContainer__Zn60F",
	"traitValue": "Token_traitValue__XwN_d",
	"traitName": "Token_traitName__fuEIa",
	"eventContainer": "Token_eventContainer__oHYks",
	"txHashArrow": "Token_txHashArrow__r_yPm",
	"pricingContainer": "Token_pricingContainer__Q0y0k",
	"pricingInfo": "Token_pricingInfo__hnOl7",
	"pricingValue": "Token_pricingValue__lAxuo",
	"buyButton": "Token_buyButton__I9joZ",
	"listingTimeContainer": "Token_listingTimeContainer__ZZbVs",
	"listingTime": "Token_listingTime__qVFcG",
	"or": "Token_or__myhNn",
	"btn": "Token_btn__LsuZc"
};


/***/ }),

/***/ 7879:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const toastStyle = {
    borderRadius: "4px",
    background: "#03ECEB",
    color: "#fff",
    "white-space": "pre-wrap",
    "word-break": "break-word"
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (toastStyle);


/***/ })

};
;